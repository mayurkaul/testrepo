# -*- encoding: utf-8 -*-

import base64
import json
import os
import pickle
import re
import sys
from io import BytesIO
import chardet

import matplotlib.pyplot as plt
import nltk
import numpy as np
import pandas as pd
import plotly
import plotly.express as px
import plotly.graph_objects as go
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from wordcloud import WordCloud, STOPWORDS


# Global variables declaration

class SentimentEngine():
    df = None
    analyser = None
    stop_words = None
    stopwordsPlot = None

    def create_plot_json(self, df):

        fig = px.scatter(df, x="Date", y="sentiment", color="rating",
                         size='sentimentAbs', hover_data=['review'])
        fig.update_layout(title_text='Sentiment weightages',
                          xaxis_rangeslider_visible=True)

        graphJSON = json.dumps(fig.data, cls=plotly.utils.PlotlyJSONEncoder)
        return graphJSON

    def whereami(self):
        print(sys._getframe(1).f_code.co_name)

    def getfiledatafromcsv(self, path):
        big_frame = pd.DataFrame()

        for file in os.listdir(path):
            if file.endswith('.csv'):

                # get encoding of file
                with open(path+"/"+file, 'rb') as rawdata:
                    result = chardet.detect(rawdata.read(10000))

                if(result['confidence']>0.6):
                    df = pd.read_csv(path + "/" + file, encoding=result['encoding'])
                else:
                    df = pd.read_csv(path + "/" + file, encoding='utf-8')

                big_frame = big_frame.append(df, ignore_index=True)
        return big_frame

    def sentiment_analyzer_scores(self, analyser, sentence):
        score = analyser.polarity_scores(sentence)['compound']
        # print(score)
        if score >= 0.05:
            return 1
        elif (score > -0.05 and score < 0.05):
            return 1
        else:
            return 0

    def preprocess_data(self, df, should_cleanup):
        self.whereami()
        self.analyser = SentimentIntensityAnalyzer()
        nltk.download('stopwords')
        self.stop_words = set(stopwords.words("english"))
        # remane all columns
        df.rename(columns={'App Version Code':'VersionCode',
                            'App Version Name':'VersionName',
                            'Review Submit Millis Since Epoch':'Date',
                        'Star Rating':'rating','Review Text':'review'}, 
                    inplace=True)
        
        # Convert text to lowercase
        df['review'] = df['review'].str.strip().str.lower()
        
        # clean VersionCode column
        df['VersionCode'].replace('', np.nan, inplace=True)
        df['VersionCode'].replace(' ', np.nan, inplace=True)
        
        # clean all rows having empty Version code now
        df.dropna(subset=['VersionCode'], inplace=True)
        
        # convert VersionCode as float for computation
        df['VersionCode']=df['VersionCode'].astype('int')
        
        df = df[['VersionCode', 'VersionName','Date','review','rating']]

        df['review'].replace(np.nan, " ", inplace=True)
        
        df.sort_values('VersionCode', inplace=True)
        print(df.head())

        if should_cleanup:
            df['Date'] = pd.to_datetime(df['Date'], unit='ms')
        else:
            df['Date'] = pd.to_datetime(df['Date'], unit='s')

        
        df = df.assign(polarity=[self.sentiment_analyzer_scores(self.analyser, sentence) for sentence in df['review']])
        df = df.assign(sentiment=[self.analyser.polarity_scores(sentence)['compound']for sentence in df['review']])
        # doing the rating correction for 4 and above
        df['polarity'] = np.where(df['rating'] >= 4, 1, df['polarity'])
        df['sentimentAbs'] = df['sentiment'].abs()
        # removing edge cases
        if should_cleanup :
            df = df[((df.VersionCode - df.VersionCode.mean()) / df.VersionCode.std()).abs() < 3]
        return df

    def getcustomcorpus(self, data, n=None):
        self.whereami()
        nltk.download('stopwords')
        self.stop_words = set(stopwords.words("english"))
        corpus = []
        size = len(data)
        for i in range(size):
            
            text = data[i]
            #Remove punctuations
            text = re.sub('[^a-zA-Z]', ' ', data[i])

            #Convert to lowercase
            text = text.lower()

            #remove tags
            text=re.sub("&lt;/?.*?&gt;"," &lt;&gt; ",text)

            # remove special characters and digits
            text=re.sub("(\\d|\\W)+"," ",text)

            ##Convert to list from string
            text = text.split()

            # ##Stemming
            # ps=PorterStemmer()
            #Lemmatisation
            lem = WordNetLemmatizer()
            text = [lem.lemmatize(word) for word in text if not word in  
                    self.stop_words]
            text = " ".join(text)
            corpus.append(text)
        return corpus


    #Most frequently occuring Tri-grams
    def get_top_words(self, corpus, n=None):
        self.whereami()
        vec1 = CountVectorizer(ngram_range=(4,10)).fit(corpus)
        bag_of_words = vec1.transform(corpus)
        sum_words = bag_of_words.sum(axis=0) 
        words_freq = [(word, sum_words[0, idx]) for word, idx in     
                    vec1.vocabulary_.items()]
        words_freq =sorted(words_freq, key = lambda x: x[1], 
                    reverse=True)
        return words_freq[:n]

    def filterdata(self, data, duration):
        #date = duration.year
        return data[data['Date'] > duration]

    def loaddatafrompickle(self,name):
        data = None
        try:
            with open('pickles/'+name,'rb') as f:
                print('Loading pickle')
                data = pickle.load(f)
        except Exception as e:
            print(e)
            data = None

        return data
    def savedatatopickle(self, data, name):
        with open('pickles/'+name, 'wb') as f:
            pickle.dump(data, f)
        return None

    def generate_wordcloud(self, data): # optionally add: stopwords=STOPWORDS and change the arg below
        text=''
        stopwordsPlot = set(STOPWORDS)
        stopwordsPlot.add('app')
        for i in range(len(data)):
            sentence = data[i]
            text += ' %s' % sentence
        
        wordcloud = WordCloud(relative_scaling = 0.5,
                            scale=5,
                            stopwords = stopwordsPlot, width=400, height=400
                            ).generate(text)
        plt.figure(figsize=(20, 20), facecolor='k')
        plt.imshow(wordcloud)
        plt.axis("off")
        plt.tight_layout(pad=0)

        figfile = BytesIO()
        plt.savefig(figfile, format='png', facecolor='k', bbox_inches='tight')
        figfile.seek(0)  # rewind to beginning of file
        retval = base64.b64encode(figfile.getvalue())
        plt.close('all')
        return retval

    def get_words(self, path, data, duration, is_positive):
        stop_words = set(stopwords.words("english"))
        ##Creating a list of custom stopwords
        new_words = ["barclays"]
        stop_words = stop_words.union(new_words)
        if is_positive:
            frameData = data.loc[data['polarity'] == 1]
        else:
            frameData = data.loc[data['polarity'] == 0]

        top_words = self.get_top_words(self.getcustomcorpus(np.array(frameData['review'])), n=20)
        words = pd.DataFrame(top_words)
        words.columns=["Summary", "Freq"]
        self.savedatatopickle(words,'words_'+ os.path.basename(path) + str(duration)+ str(is_positive)+'.pickle')
        return words

    def generatePlotBar(self, data):

        fig = px.bar(data, x="Summary", y="Freq",
                     hover_data=['Freq'], color='Freq')
        fig.update_layout(
            autosize=False,
            margin=go.layout.Margin(
                l=0,
                r=0,
                b=0,
                t=0,
                pad=0
            )
        )
        fig.update_yaxes(automargin=True)
        graphJSON = json.dumps(fig.data, cls=plotly.utils.PlotlyJSONEncoder)
        return graphJSON
