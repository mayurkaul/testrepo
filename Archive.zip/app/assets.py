# -*- encoding: utf-8 -*-
"""
Flask Boilerplate
Author: AppSeed.us - App Generator 
"""

# Resources used 
class Assets:

    BRAND_NAME = 'AppSeed.us'
    BRAND_INFO = 'React, Vue App Generator'  
