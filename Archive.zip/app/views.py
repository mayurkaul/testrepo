# -*- encoding: utf-8 -*-
"""
Now UI Dashboard - coded in Flask
Author: AppSeed.us - App Generator 
"""
import sys
from datetime import datetime
import os
from flask import render_template
from flask import request
# all the imports necessary
from werkzeug.exceptions import abort

from app import app
from .sentiments import SentimentEngine

se = SentimentEngine()
data = None


@app.route('/index.html')
def rootPage():
    return index('index.html')


@app.route('/index-appstore.html')
def rootAppstorePage():
    return index('index-appstore.html')


# App main route + generic routing

@app.route('/', defaults={'path': 'index.html'}, methods=['GET', 'POST'])
def index(path):
    print('in Path' + path)
    content = None

    try:
        duration = request.args.get('duration')
        if duration is None or duration == 'All':
            duration = datetime(1970, 1, 1)
        else:
            duration = datetime(int(duration), 1, 1)
        print(duration)
        filename = app.config['ANDROID_APP_DATA_FOLDER'] if path == 'index.html' else app.config['IOS_APP_DATA_FOLDER']
        data = loadDataFromPickle(duration, filename, path == 'index.html')
        jsonData = getJsonToRender(data)
        positive_bar_chart, positive_word_cloud = getBarChartData(path, data, duration.year, True)
        negative_bar_chart, negative_word_cloud = getBarChartData(path, data, duration.year, False)

        # try to match the pages defined in -> themes/light-bootstrap/pages/
        return render_template('layouts/default.html',
                               content=render_template('pages/' + path),
                               plot=jsonData,
                               positivecloud=positive_word_cloud.decode('utf8'),
                               negativecloud=negative_word_cloud.decode('utf8'),
                               positivebar=positive_bar_chart,
                               negativebar=negative_bar_chart,
                               homepage_selected=path == 'index.html'
                               )
    except:
        print(sys.exc_info())
        print('error occurred')
        abort(404)


def getBarChartData(path, data, duration, is_positive):
    _words = se.loaddatafrompickle('words_' + os.path.basename(path) + str(duration) + str(is_positive) + '.pickle')
    if (_words is None):
        print('Loading words')
        _words = se.get_words(path, data, duration, is_positive)

    _WordCloud = se.generate_wordcloud(_words['Summary'])
    _BarChart = se.generatePlotBar(_words)
    return _BarChart, _WordCloud


def getJsonToRender(data):
    jsonData = se.create_plot_json(data)
    return jsonData


def loadDataFromPickle(duration, filename, should_cleanup):
    data = se.loaddatafrompickle('dataset' + os.path.basename(filename) + str(duration.year) + '.pickle')
    print('loaded data')
    if data is None:
        print('Data not present, Creating data')
        data = se.getfiledatafromcsv(filename)
        data = se.preprocess_data(data, should_cleanup)
        data = se.filterdata(data, duration)
        se.savedatatopickle(data, 'dataset' + os.path.basename(filename) + str(duration.year) + '.pickle')
    return data


# @app.route('/favicon.ico')
# def favicon():
#    return send_from_directory(os.path.join(app.root_path, 'static'),
#                               'favicon.ico', mimetype='image/vnd.microsoft.icon')

# @app.route('/sitemap.xml')
# def sitemap():
#    return send_from_directory(os.path.join(app.root_path, 'static'),
#                               'sitemap.xml')

# ------------------------------------------------------

# error handling
# most common error codes have been added for now
# TO DO:
# they could use some styling so they don't look so ugly

def http_err(err_code):
    err_msg = 'Oups !! Some internal error ocurred. Thanks to contact support.'

    if 400 == err_code:
        err_msg = "It seems like you are not allowed to access this link."

    elif 404 == err_code:
        err_msg = "The URL you were looking for does not seem to exist."
        err_msg += "<br /> Define the new page in /pages"

    elif 500 == err_code:
        err_msg = "Internal error. Contact the manager about this."

    else:
        err_msg = "Forbidden access."

    return err_msg


@app.errorhandler(401)
def e401(e):
    return http_err(401)  # "It seems like you are not allowed to access this link."


@app.errorhandler(404)
def e404(e):
    return http_err(404)  # "The URL you were looking for does not seem to exist.<br><br>
    # If you have typed the link manually, make sure you've spelled the link right."


@app.errorhandler(500)
def e500(e):
    return http_err(500)  # "Internal error. Contact the manager about this."


@app.errorhandler(403)
def e403(e):
    return http_err(403)  # "Forbidden access."


@app.errorhandler(410)
def e410(e):
    return http_err(410)  # "The content you were looking for has been deleted."
