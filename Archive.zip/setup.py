from setuptools import setup
import setuptools

setup(
    name='sentiment-analysis',
    version='1.0',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='Mayur Kaul',
    author_email='mayur.kaul@barclays.com',
    description='',
    install_requires=[
        "flask",
    ],
)
